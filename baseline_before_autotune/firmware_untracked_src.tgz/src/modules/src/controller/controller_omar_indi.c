/*
The MIT License (MIT)

Copyright (c) 2024 Khaled Wahba

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*
This controller is based on the following publication:

Taeyoung Lee, Melvin Leok, and N. Harris McClamroch
Geometric Tracking Control of a Quadrotor UAV on SE(3)
CDC 2010

* Difference to Mellinger:
  * Different angular velocity error
  * Higher-order terms in attitude controller
*/

#include <math.h>
#include <string.h>

#include "log.h"
#include "param.h"

#include "math3d.h"
#include "controller_omar_indi.h"
#include "physicalConstants.h"
#include "power_distribution.h"
#include "platform_defaults.h"

#include "filter.h"
#include "usec_time.h"
#include "debug.h"
#include "fbl_law.h"
#include "fbl_residual.h"
#include "attitude_controller.h"

static controllerOmarIndi_t g_self = {
  .mass = CF_MASS,

  // Inertia matrix (diagonal matrix), see
  // System Identification of the Crazyflie 2.0 Nano Quadrocopter
  // BA theses, Julian Foerster, ETHZ
  // https://polybox.ethz.ch/index.php/s/20dde63ee00ffe7085964393a55a91c7
  .J = {16.571710e-6, 16.655602e-6, 29.261652e-6}, // kg m^2

  // Position PID
  .Kpos_P = {7.0, 7.0, 7.0}, // Kp in paper
  .Kpos_P_limit = 100,
  .Kpos_D = {4.0, 4.0, 4.0}, // Kv in paper
  .Kpos_D_limit = 100,
  .Kpos_I = {0.0, 0.0, 0.0}, // not in paper
  .Kpos_I_limit = 2,

  // Attitude PID
  .KR = {0.007, 0.007, 0.008},
  .Komega = {0.00115, 0.00115, 0.002},
  .KI = {0.03, 0.03, 0.03},

  // INDI
  .indi = 0,

  // Learned FBL (Strategy 3): configuration at boot, literal copy of what fbl_defaults() used to set at every controller init (preset 1 = ours, see
  // fbl_apply_preset). The state (law, peers, counters) is zero here and reset by fbl_runtime_reset() at init. The configuration must NOT be reset at the
  // controller init: CS2 writes the yaml params alphabetically and stabilizer.controller last, so an init that reset the config wiped ctrlFbl.en / cd
  // (2026-10-24, first FBL flights ran as S0).
  // 2026-10-25: defaults = the authors' structure for the whole flight: FBL from takeoff to landing like S0-S3 fly their controller
  // (z_on / z_off far below the floor: no handover to the Omar controller), no tilt latch (tilt_max 180 deg) and no body-rate limit
  // (w_max 0, the bundle has none). The 2026-10-24 behaviour (handover at 0.15 / 0.10 m, latch 60 deg, limit 20 rad/s) is these parameters.
  .fbl = {
    .en = 0, .c_d = 0.43f, .z_on = -10.0f, .z_off = -20.0f, .tilt_max_deg = 180.0f, .preset = 1,
    .kp_xy = 14.0f, .kp_z = 11.25f, .kv_xy = 9.5f, .kv_z = 5.4f, .ki_xy = 12.0f, .ki_z = 12.0f, .kr_xy = 59.5f, .kr_z = 35.0f,
    .J = {2.395e-5f, 2.395e-5f, 3.235e-5f}, .beta = 0.4f, .gamma = 0.1f, .w_max = 0.0f, .inner = 1, .abg_on_new = 0, .nn_en = 1,
  },
};


static bool rpm_deck_available;
static logVarId_t logVarRpm1;
static logVarId_t logVarRpm2;
static logVarId_t logVarRpm3;
static logVarId_t logVarRpm4;

static Butterworth2LowPass filter_acc_rpm[3];
static Butterworth2LowPass filter_acc_imu[3];
static Butterworth2LowPass filter_tau_rpm[3];
static Butterworth2LowPass filter_angular_acc[3];

static inline struct vec vclampscl(struct vec value, float min, float max) {
  return mkvec(
    clamp(value.x, min, max),
    clamp(value.y, min, max),
    clamp(value.z, min, max));
}

static inline void update_butterworth_2_low_pass_vec(Butterworth2LowPass filter[3], struct vec value) {
  update_butterworth_2_low_pass(&filter[0], value.x);
  update_butterworth_2_low_pass(&filter[1], value.y);
  update_butterworth_2_low_pass(&filter[2], value.z);
}

static inline struct vec get_butterworth_2_low_pass_vec(Butterworth2LowPass filter[3]) {
  float x = get_butterworth_2_low_pass(&filter[0]);
  float y = get_butterworth_2_low_pass(&filter[1]);
  float z = get_butterworth_2_low_pass(&filter[2]);
  return mkvec(x, y, z);
}


// ---- Learned FBL branch (Strategy 3, 2026-10-19) -------------------------------------------------------------------------------------
// Additive and inert unless fbl.en = 1. Above fbl.z_on the FBL law replaces the position and attitude controllers below (thrust along the measured body
// z axis, body-rate loop, downwash compensation from the ROM table); below z_off, on a tilt fault and on any non-finite value the Omar controller runs
// (so takeoff and landing are Omar's). Sources: fbl_law.c, fbl_residual.c (host-tested against the authors' code, docs/fbl/PORT_SPEC.md).
// Gain presets. 0 = the authors' (Hsieh et al.) values exactly as in their code (30 g simulated vehicle, kept for reference/comparison);
// 1 = ours: position loop (kp, kv, ki_xy) 0.25x, rate loop 0.25x, ki_z 12 -- tuned in the C-in-the-loop plant with 44 ms motor lag
// (docs/fbl/GAIN_TUNING_2026-10-20.md). The authors' values are unstable with that lag in simulation.
static void fbl_apply_preset(fbl_cfg_t* f, uint8_t preset)
{
  if (preset == 0) {
    f->kp_xy = 56.0f; f->kp_z = 45.0f; f->kv_xy = 38.0f; f->kv_z = 21.6f; f->ki_xy = 48.0f; f->ki_z = 3.0f; f->kr_xy = 238.0f; f->kr_z = 140.0f;
  } else {
    f->kp_xy = 14.0f; f->kp_z = 11.25f; f->kv_xy = 9.5f; f->kv_z = 5.4f; f->ki_xy = 12.0f; f->ki_z = 12.0f; f->kr_xy = 59.5f; f->kr_z = 35.0f;
  }
}

static void fbl_preset_changed(void)
{
  fbl_apply_preset(&g_self.fbl, g_self.fbl.preset);
}

static void fbl_runtime_reset(controllerOmarIndi_t* self)
{
  // state only; the configuration (en, c_d, z_on, preset and gains, ...) survives the controller init, see the initializer of g_self
  fbl_cfg_t* f = &self->fbl;
  f->active = 0; f->tripped = 0; f->steps = 0; f->faults = 0;
  f->res_az = 0.0f; f->res_jz = 0.0f; f->thrust = 0.0f;
  f->acc_cmd = vzero(); f->w_des = vzero(); f->yaw_sp = 0.0f;
  f->abg_v[0] = f->abg_v[1] = f->abg_v[2] = 0.0f; f->abg_age = 0.0f;
  fbl_law_reset(&f->law); fbl_reset(&f->peers);
}

static float fbl_cap_angle(float angle)
{
  // capAngle() of controller_pid.c (static there)
  float result = angle;
  while (result > 180.0f) { result -= 360.0f; }
  while (result < -180.0f) { result += 360.0f; }
  return result;
}

// inner = 1: the inner loop the paper's hardware used (Hsieh et al. 2026, Sec. 5.2: FBL sent thrust + body rates, "rely on the high-frequency PID
// controller onboard"). Reproduces controller_pid.c in rate mode (roll / pitch / yaw modeVelocity) step by step: yaw rate integrated into a yaw
// setpoint, yaw attitude PID -> yaw rate desired, roll / pitch attitude PIDs reset, rate PIDs on (gyro.x, -gyro.y, gyro.z), legacy mixer, yaw negated.
// Stock gains (pid_rate.*, pid_attitude.yaw_*); the FBL rate gains kr_xy / kr_z and J are not used. Only difference to stock: at the in-air switch-on
// the rate PIDs are primed with the current gyro so the D term (on the measurement) does not kick; stock resets them on the ground (gyro ~ 0).
static void fbl_inner_stock(fbl_cfg_t* f, control_t *control, const sensorData_t *sensors, const state_t *state, bool switch_on,
                            float thrust, const float w_des[3], float max_thrust, float dt)
{
  const float rate_des_roll = degrees(w_des[0]), rate_des_pitch = -degrees(w_des[1]);
  if (switch_on) {
    attitudeControllerResetAllPID(state->attitude.roll, state->attitude.pitch, state->attitude.yaw);
    attitudeControllerCorrectRatePID(sensors->gyro.x, -sensors->gyro.y, sensors->gyro.z, sensors->gyro.x, -sensors->gyro.y, sensors->gyro.z);  // prime (zero error)
    f->yaw_sp = state->attitude.yaw;
  }
  // controller_pid.c: modeVelocity yaw -> attitudeDesired.yaw
  f->yaw_sp = fbl_cap_angle(f->yaw_sp + degrees(w_des[2]) * dt);
  const float yawMaxDelta = attitudeControllerGetYawMaxDelta();
  if (yawMaxDelta != 0.0f) {
    const float delta = fbl_cap_angle(f->yaw_sp - state->attitude.yaw);
    if (delta > yawMaxDelta) { f->yaw_sp = state->attitude.yaw + yawMaxDelta; }
    else if (delta < -yawMaxDelta) { f->yaw_sp = state->attitude.yaw - yawMaxDelta; }
  }
  f->yaw_sp = fbl_cap_angle(f->yaw_sp);

  float rr, rp, ry;
  attitudeControllerCorrectAttitudePID(state->attitude.roll, state->attitude.pitch, state->attitude.yaw, 0.0f, 0.0f, f->yaw_sp, &rr, &rp, &ry);
  attitudeControllerResetRollAttitudePID(state->attitude.roll);
  attitudeControllerResetPitchAttitudePID(state->attitude.pitch);
  attitudeControllerCorrectRatePID(sensors->gyro.x, -sensors->gyro.y, sensors->gyro.z, rate_des_roll, rate_des_pitch, ry);
  attitudeControllerGetActuatorOutput(&control->roll, &control->pitch, &control->yaw);
  control->yaw = -control->yaw;
  control->controlMode = controlModeLegacy;
  control->thrust = thrust / max_thrust * UINT16_MAX;      // per-motor uint16, force-linear with battery compensation: F_motor = u / 65535 * THRUST_MAX
  if (control->thrust == 0) {                              // controller_pid.c: zero thrust -> zero commands, reset
    control->roll = 0; control->pitch = 0; control->yaw = 0;
    attitudeControllerResetAllPID(state->attitude.roll, state->attitude.pitch, state->attitude.yaw);
    f->yaw_sp = state->attitude.yaw;
  }
}

static bool controllerOmarFbl(controllerOmarIndi_t* self, control_t *control, const setpoint_t *setpoint, const sensorData_t *sensors,
                              const state_t *state, float desiredYaw, float dt)
{
  fbl_cfg_t* f = &self->fbl;
  const float z = state->position.z;
  if (f->tripped) {
    if (z < f->z_off) { f->tripped = 0; }
    f->active = 0; fbl_law_reset(&f->law);
    return false;
  }
  bool switch_on = false;
  if (f->active) { if (z < f->z_off) { f->active = 0; } } else { if (z > f->z_on) { f->active = 1; switch_on = true; } }
  if (!f->active) { fbl_law_reset(&f->law); return false; }

  struct quat q = mkquat(state->attitudeQuaternion.x, state->attitudeQuaternion.y, state->attitudeQuaternion.z, state->attitudeQuaternion.w);
  struct mat33 R = quat2rotmat(q);
  if (R.m[2][2] < cosf(radians(f->tilt_max_deg))) { f->tripped = 1; f->faults++; f->active = 0; return false; }

  fbl_gains_t g;
  for (int i = 0; i < 3; i++) {
    const bool xy = (i < 2);
    g.pos_kp[i] = xy ? f->kp_xy : f->kp_z; g.vel_kp[i] = xy ? f->kv_xy : f->kv_z; g.int_kp[i] = xy ? f->ki_xy : f->ki_z; g.rate_k[i] = xy ? f->kr_xy : f->kr_z;
  }
  g.inertia[0] = f->J.x; g.inertia[1] = f->J.y; g.inertia[2] = f->J.z;
  g.mass = self->mass; g.gravity = GRAVITY_MAGNITUDE; g.abg_beta = f->beta; g.abg_gamma = f->gamma; g.w_max = f->w_max;

  const float pos[3] = {state->position.x, state->position.y, state->position.z};
  const float vel[3] = {state->velocity.x, state->velocity.y, state->velocity.z};
  fbl_ref_t ref = {
    .x = {setpoint->position.x, setpoint->position.y, setpoint->position.z},
    .x_dot = {setpoint->velocity.x, setpoint->velocity.y, setpoint->velocity.z},
    .x_ddot = {setpoint->acceleration.x, setpoint->acceleration.y, setpoint->acceleration.z},
    .x_dddot = {setpoint->jerk.x, setpoint->jerk.y, setpoint->jerk.z},
  };
  float acc_cmd[3], jerk_cmd[3];
  if (f->abg_on_new) {
    // estimator at the measurement rate (the EKF velocity changes only every ~5-6 ms): update it only on a new sample, with the time since the last one;
    // the integral keeps the controller rate. The law's first call (after a reset) initialises the estimator.
    f->abg_age += dt;
    float dt_est = 0.0f;
    if (!f->law.init || vel[0] != f->abg_v[0] || vel[1] != f->abg_v[1] || vel[2] != f->abg_v[2]) {
      dt_est = f->abg_age; f->abg_age = 0.0f;
      f->abg_v[0] = vel[0]; f->abg_v[1] = vel[1]; f->abg_v[2] = vel[2];
    }
    fbl_law_position_dt2(&f->law, &g, dt_est, dt, pos, vel, &ref, acc_cmd, jerk_cmd);
  } else {
    fbl_law_position_dt(&f->law, &g, dt, pos, vel, &ref, acc_cmd, jerk_cmd);
  }

  fbl_res_t res;
  fbl_residual_set_nn(f->nn_en ? &fbl_nn_weights : 0);      // weak symbol: no weights linked -> 0 -> ROM only
  fbl_residual_eval(&f->peers, pos, vel, f->c_d, &res);

  float Rm[9];
  for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) Rm[3 * i + j] = R.m[i][j];
  const float w[3] = {radians(sensors->gyro.x), radians(sensors->gyro.y), radians(sensors->gyro.z)};
  const float res_ang[3] = {0.0f, 0.0f, 0.0f};
  float thrust, w_des[3], torque[3];
  fbl_law_command(Rm, w, acc_cmd, jerk_cmd, desiredYaw, radians(setpoint->attitudeRate.yaw), res.acc, res.jerk, res_ang, &g, &thrust, w_des, torque);

  const float max_thrust = powerDistributionGetMaxThrust();
  if (!(isfinite(thrust) && isfinite(torque[0]) && isfinite(torque[1]) && isfinite(torque[2]))) { f->tripped = 1; f->faults++; f->active = 0; return false; }
  if (thrust < 0.0f) thrust = 0.0f;
  if (thrust > max_thrust) thrust = max_thrust;

  if (f->inner == 1) {
    fbl_inner_stock(f, control, sensors, state, switch_on, thrust, w_des, max_thrust, dt);
    // logged torque = the torque the legacy commands produce (power_distribution_quadrotor.c Legacy vs ForceTorque, per-motor uint16 force-linear)
    const float k = 4.0f * THRUST_MAX / UINT16_MAX;
    const int16_t r = control->roll / 2.0f, p = control->pitch / 2.0f;
    torque[0] = k * 0.707106781f * ARM_LENGTH * r;
    torque[1] = -k * 0.707106781f * ARM_LENGTH * p;
    torque[2] = -k * THRUST2TORQUE * control->yaw;
  } else {
    control->controlMode = controlModeForceTorque;
    control->thrustSi = thrust;
    control->torque[0] = torque[0]; control->torque[1] = torque[1]; control->torque[2] = torque[2];
  }

  // state shared with the Omar logging
  self->thrustSi = thrust;
  self->u = mkvec(torque[0], torque[1], torque[2]);
  self->rpy = quat2rpy(q);
  self->omega = mkvec(w[0], w[1], w[2]);
  self->p_error = mkvec(ref.x[0] - pos[0], ref.x[1] - pos[1], ref.x[2] - pos[2]);
  self->v_error = mkvec(ref.x_dot[0] - vel[0], ref.x_dot[1] - vel[1], ref.x_dot[2] - vel[2]);
  {
    struct vec yc = mkvec(-sinf(desiredYaw), cosf(desiredYaw), 0);
    struct vec F_d = mkvec(acc_cmd[0] - res.acc[0], acc_cmd[1] - res.acc[1], acc_cmd[2] - res.acc[2] + GRAVITY_MAGNITUDE);
    struct vec xb = vnormalize(vcross(yc, F_d));
    struct vec yb = vnormalize(vcross(F_d, xb));
    struct vec zb = vcross(xb, yb);
    self->R_des = mcolumns(xb, yb, zb);
    self->rpy_des = quat2rpy(mat2quat(self->R_des));
  }
  f->steps++; f->res_az = res.acc[2]; f->res_jz = res.jerk[2]; f->thrust = thrust;
  f->acc_cmd = mkvec(acc_cmd[0], acc_cmd[1], acc_cmd[2]); f->w_des = mkvec(w_des[0], w_des[1], w_des[2]);
  return true;
}

void controllerOmarIndiReset(controllerOmarIndi_t* self)
{
  self->i_error_pos = vzero();
  self->i_error_att = vzero();
}

void controllerOmarIndiInit(controllerOmarIndi_t* self)
{
  // copy default values (bindings), or NOP (firmware)
  *self = g_self;
  ns2_reset(&self->ns2);
  ns2_publish_ready();
  fbl_runtime_reset(self);
  attitudeControllerInit(1.0f / ATTITUDE_RATE);   // stock attitude / rate PIDs for the FBL inner = 1 path (guarded by isInit; no effect on other paths)

  paramVarId_t idDeckBcRpm = paramGetVarId("deck", "bcRpm");
  logVarRpm1 = logGetVarId("rpm", "m1");
  logVarRpm2 = logGetVarId("rpm", "m2");
  logVarRpm3 = logGetVarId("rpm", "m3");
  logVarRpm4 = logGetVarId("rpm", "m4");

  rpm_deck_available = (paramGetUint(idDeckBcRpm) == 1);

	for (int8_t i = 0; i < 3; i++) {
    const float cutoff = 30; // Hz
		init_butterworth_2_low_pass(&filter_acc_rpm[i], 1 / (2 * M_PI_F * cutoff), 1.0 / ATTITUDE_RATE, 0.0f);
		init_butterworth_2_low_pass(&filter_acc_imu[i], 1 / (2 * M_PI_F * cutoff), 1.0 / ATTITUDE_RATE, 0.0f);

		init_butterworth_2_low_pass(&filter_tau_rpm[i], 1 / (2 * M_PI_F * cutoff), 1.0 / ATTITUDE_RATE, 0.0f);
		init_butterworth_2_low_pass(&filter_angular_acc[i], 1 / (2 * M_PI_F * cutoff), 1.0 / ATTITUDE_RATE, 0.0f);
	}

  self->timestamp_prev = usecTimestamp();
  self->omega_prev = vzero();

  controllerOmarIndiReset(self);
}

bool controllerOmarIndiTest(controllerOmarIndi_t* self)
{
  return true;
}

void controllerOmarIndi(controllerOmarIndi_t* self, control_t *control, const setpoint_t *setpoint,
                                         const sensorData_t *sensors,
                                         const state_t *state,
                                         const uint32_t tick)
{

  if (!RATE_DO_EXECUTE(ATTITUDE_RATE, tick)) {
    return;
  }

  // uint64_t startTime = usecTimestamp();

  float dt = (float)(1.0f/ATTITUDE_RATE);
  // struct vec dessnap = vzero();
  // Address inconsistency in firmware where we need to compute our own desired yaw angle
  // Rate-controlled YAW is moving YAW angle setpoint
  float desiredYaw = 0; //rad
  if (setpoint->mode.yaw == modeVelocity) {
    desiredYaw = radians(state->attitude.yaw + setpoint->attitudeRate.yaw * dt);
  } else if (setpoint->mode.yaw == modeAbs) {
    desiredYaw = radians(setpoint->attitude.yaw);
  } else if (setpoint->mode.quat == modeAbs) {
    struct quat setpoint_quat = mkquat(setpoint->attitudeQuaternion.x, setpoint->attitudeQuaternion.y, setpoint->attitudeQuaternion.z, setpoint->attitudeQuaternion.w);
    self->rpy_des = quat2rpy(setpoint_quat);
    desiredYaw = self->rpy_des.z;
  }

  // INDI
  float t1 = 0.0f, t2 = 0.0f, t3 = 0.0f, t4 = 0.0f;
  // The rpm-based force estimate is also computed with indi = 0 (S0, S2) so that the INDI estimate below can be logged under every strategy; it only
  // enters the control when indi & 1.
  if (rpm_deck_available) {
    // compute expected acceleration based on rpm measurements (world frame)
    uint16_t rpm1 = logGetUint(logVarRpm1);
    uint16_t rpm2 = logGetUint(logVarRpm2);
    uint16_t rpm3 = logGetUint(logVarRpm3);
    uint16_t rpm4 = logGetUint(logVarRpm4);

    t1 = MOTORRPM2FORCE * powf(rpm1 * 2.0f * M_PI_F / 60.0f, 2);
    t2 = MOTORRPM2FORCE * powf(rpm2 * 2.0f * M_PI_F / 60.0f, 2);
    t3 = MOTORRPM2FORCE * powf(rpm3 * 2.0f * M_PI_F / 60.0f, 2);
    t4 = MOTORRPM2FORCE * powf(rpm4 * 2.0f * M_PI_F / 60.0f, 2);

    // DEBUG
    if (self->indi && tick % 500 == 0) {
      DEBUG_PRINT("INDI r %d %d %d %d\n", rpm1, rpm2, rpm3, rpm4);
      
      DEBUG_PRINT("INDI t %f %f %f %f\n", (double)t1, (double)t2, (double)t3, (double)t4);
    }
  }
  struct vec xc = mkvec(cosf(desiredYaw), sinf(desiredYaw), 0);
  struct vec yc = mkvec(-sinf(desiredYaw), cosf(desiredYaw), 0);

  if (self->Kpos_I.z != 0.0f
      && setpoint->mode.x != modeAbs
      && setpoint->mode.y != modeAbs
      && setpoint->mode.z != modeAbs) {
    self->i_error_pos.z = 0.0f;
  }

  // Learned FBL (Strategy 3, additive): when fbl.en = 1 and the FBL law accepts this tick it replaces the position and attitude controllers below.
  if (self->fbl.en && (setpoint->mode.x == modeAbs || setpoint->mode.y == modeAbs || setpoint->mode.z == modeAbs)) {
    if (controllerOmarFbl(self, control, setpoint, sensors, state, desiredYaw, dt)) {
      return;
    }
  } else if (self->fbl.active || self->fbl.tripped) {
    self->fbl.active = 0; self->fbl.tripped = 0; fbl_law_reset(&self->fbl.law);
  }

  // Position controller
  if (   setpoint->mode.x == modeAbs
      || setpoint->mode.y == modeAbs
      || setpoint->mode.z == modeAbs) {
    struct vec pos_d = mkvec(setpoint->position.x, setpoint->position.y, setpoint->position.z);
    struct vec vel_d = mkvec(setpoint->velocity.x, setpoint->velocity.y, setpoint->velocity.z);
    struct vec acc_d = mkvec(setpoint->acceleration.x, setpoint->acceleration.y, setpoint->acceleration.z + GRAVITY_MAGNITUDE);
    struct vec statePos = mkvec(state->position.x, state->position.y, state->position.z);
    struct vec stateVel = mkvec(state->velocity.x, state->velocity.y, state->velocity.z);

    // errors
    struct vec pos_e = vclampscl(vsub(pos_d, statePos), -self->Kpos_P_limit, self->Kpos_P_limit);
    struct vec vel_e = vclampscl(vsub(vel_d, stateVel), -self->Kpos_D_limit, self->Kpos_D_limit);
    self->i_error_pos = vadd(self->i_error_pos, vscl(dt, pos_e));
    if (self->Kpos_I.z != 0.0f) {
      self->i_error_pos.z = clamp(self->i_error_pos.z, -self->Kpos_I_limit, self->Kpos_I_limit);
    }
    self->p_error = pos_e;
    self->v_error = vel_e;

    // desired acceleration
    struct vec i_term = veltmul(self->Kpos_I, self->i_error_pos);
    if (self->Kpos_I.z != 0.0f) {
      i_term.x = 0.0f;
      i_term.y = 0.0f;
      i_term.z = self->Kpos_I.z * self->i_error_pos.z;
    }
    struct vec a_d = vadd4(
      acc_d,
      veltmul(self->Kpos_D, vel_e),
      veltmul(self->Kpos_P, pos_e),
      i_term);

    // NS2 learned residual (2026-10-14). Evaluated and logged under every strategy (rnn.* group of traj_iface.c),
    // used only when rnn.en = 1: the prediction estimates the measured residual and is subtracted, the same sign
    // as Omar's own INDI term below. With rnn.en = 0 a_d is untouched (bit-identical to the unpatched controller).
    {
      const float ns2_pos[3] = {state->position.x, state->position.y, state->position.z};
      const float ns2_vel[3] = {state->velocity.x, state->velocity.y, state->velocity.z};
      ns2_update(&self->ns2, ns2_pos, ns2_vel, self->mass, tick);
      if (ns2_active()) {
        a_d = vsub(a_d, mkvec(self->ns2.hold[0], self->ns2.hold[1], self->ns2.hold[2]));
      }
    }

    struct quat q = mkquat(state->attitudeQuaternion.x, state->attitudeQuaternion.y, state->attitudeQuaternion.z, state->attitudeQuaternion.w);
    struct mat33 R = quat2rotmat(q);
    struct vec z  = vbasis(2);

    // INDI
    // The INDI estimate (filtered a_rpm, a_imu) is updated and logged under every strategy; a_indi is applied only when indi & 1 (control unchanged for indi 0).
    struct vec a_indi = vzero();
    if (rpm_deck_available) {

      float f_rpm = t1 + t2 + t3 + t4;
      self->a_rpm = vsub(vscl(f_rpm / self->mass, mvmul(R, z)), mkvec(0.0, 0.0, 9.81f));
      update_butterworth_2_low_pass_vec(filter_acc_rpm, self->a_rpm);

      // compute acceleration based on IMU (world frame, SI unit, no gravity)
      self->a_imu = vscl(9.81, mkvec(state->acc.x, state->acc.y, state->acc.z));
      update_butterworth_2_low_pass_vec(filter_acc_imu, self->a_imu);

      self->a_rpm_filtered = get_butterworth_2_low_pass_vec(filter_acc_rpm);
      self->a_imu_filtered = get_butterworth_2_low_pass_vec(filter_acc_imu);

      if (self->indi & 1) {
        a_indi = vsub(self->a_rpm_filtered, self->a_imu_filtered);
      }

      // DEBUG
      if ((self->indi & 1) && tick % 500 == 0) {
        DEBUG_PRINT("INDI p %f %f %f, %f %f %f\n", (double)self->a_rpm_filtered.x, (double)self->a_rpm_filtered.y, (double)self->a_rpm_filtered.z, (double)self->a_imu_filtered.x, (double)self->a_imu_filtered.y, (double)self->a_imu_filtered.z);
      }
    }

    control->thrustSi = self->mass*vdot(vadd(a_d, a_indi), mvmul(R, z));

    self->thrustSi = control->thrustSi;
    // Reset the accumulated error while on the ground
    if (control->thrustSi < 0.01f) {
      controllerOmarIndiReset(self);
    }

    // Compute Desired Rotation matrix
    struct vec F_d = vadd(a_d, a_indi);
    struct vec xb = vnormalize(vcross(yc, F_d));
    struct vec yb = vnormalize(vcross(F_d, xb));
    struct vec zb = vcross(xb, yb);
    self->R_des = mcolumns(xb, yb, zb);
  } else {
    if (setpoint->mode.z == modeDisable) {
      if (setpoint->thrust < 1000) {
          control->controlMode = controlModeForceTorque;
          control->thrustSi  = 0;
          control->torque[0] = 0;
          control->torque[1] = 0;
          control->torque[2] = 0;
          controllerOmarIndiReset(self);
          return;
      }
    }
    const float max_thrust = powerDistributionGetMaxThrust(); // N
    control->thrustSi = setpoint->thrust / UINT16_MAX * max_thrust;

    struct quat q = rpy2quat(mkvec(
        radians(setpoint->attitude.roll),
        -radians(setpoint->attitude.pitch), // This is in the legacy coordinate system where pitch is inverted
        desiredYaw));
    self->R_des = quat2rotmat(q);
  }

  // Attitude controller

  // current rotation [R]
  struct quat q = mkquat(state->attitudeQuaternion.x, state->attitudeQuaternion.y, state->attitudeQuaternion.z, state->attitudeQuaternion.w);
  self->rpy = quat2rpy(q);
  struct mat33 R = quat2rotmat(q);

  // desired rotation [Rdes]
  struct quat q_des = mat2quat(self->R_des);
  self->rpy_des = quat2rpy(q_des);

  // rotation error
  struct mat33 eRM = msub(mmul(mtranspose(self->R_des), R), mmul(mtranspose(R), self->R_des));

  struct vec eR = vscl(0.5f, mkvec(eRM.m[2][1], eRM.m[0][2], eRM.m[1][0]));

  // angular velocity
  self->omega = mkvec(
    radians(sensors->gyro.x),
    radians(sensors->gyro.y),
    radians(sensors->gyro.z));

  // Compute desired omega
  struct vec xb = mcolumn(self->R_des, 0);
  struct vec yb = mcolumn(self->R_des, 1);
  struct vec zb = mcolumn(self->R_des, 2);
  struct vec desJerk = mkvec(setpoint->jerk.x, setpoint->jerk.y, setpoint->jerk.z);
  float c = control->thrustSi / self->mass;
  float B1 = c;
  float B3 = -vdot(yc, zb);
  float C3 = vmag(vcross(yc, zb));
  float D1 = vdot(xb, desJerk);
  float D2 = -vdot(yb, desJerk);
  float D3 = radians(setpoint->attitudeRate.yaw) * vdot(xc, xb);
  
  struct vec omega_des = vzero();
  if (control->thrustSi != 0) {
    omega_des.x = D2/B1;
    omega_des.y = D1/B1;
    omega_des.z = (B1*D3-B3*D1)/(B1*C3);
  }

  // Compute desired omega dot
  float setpoint_yaw_ddot = radians(setpoint->attitudeAcc.yaw);
  float setpoint_yaw_dot = radians(setpoint->attitudeRate.yaw);

  struct vec desSnap = mkvec(setpoint->snap.x, setpoint->snap.y, setpoint->snap.z);
  float c_dot = vdot(zb, desJerk);
  float E1 = vdot(xb,desSnap) - 2.0f * c_dot * omega_des.y - c * omega_des.x * omega_des.z;
  float E2 = -vdot(yb,desSnap) - 2.0f * c_dot * omega_des.x + c * omega_des.y * omega_des.z;
  float E3 = setpoint_yaw_ddot * vdot(xc, xb) + 2.0f * setpoint_yaw_dot * omega_des.z * vdot(xc, yb) - 2.0f * setpoint_yaw_dot*omega_des.y*vdot(xc,zb) - omega_des.x*omega_des.y*vdot(yc,yb) - omega_des.x*omega_des.z*vdot(yc,zb);

  self->omega_des_dot = vzero();
  if (control->thrustSi != 0) {
    self->omega_des_dot.x = E2/B1;
    self->omega_des_dot.y = E1/B1;
    self->omega_des_dot.z = (B1*E3-B3*E1)/(B1*C3);
  }


  self->omega_r = mvmul(mmul(mtranspose(R), self->R_des), omega_des);

  struct vec omega_error = vsub(self->omega, self->omega_r);
  
  // Integral part on angle
  self->i_error_att = vadd(self->i_error_att, vscl(dt, eR));

  // compute moments
  // M = -kR eR - kw ew + w x Jw - J(w x wr)
  self->u = vadd5(
    vneg(veltmul(self->KR, eR)),
    vneg(veltmul(self->Komega, omega_error)),
    vneg(veltmul(self->KI, self->i_error_att)),
    vcross(self->omega, veltmul(self->J, self->omega)),
    vneg(veltmul(self->J, vsub(mvmul(mcrossmat(self->omega), self->omega_r), mvmul(mmul(mtranspose(R), self->R_des), self->omega_des_dot)))));

  struct vec indi_moments;
  if ((self->indi & 2) && rpm_deck_available) {
    const float t2t = THRUST2TORQUE;
    const float arm = 0.707106781f * ARM_LENGTH;
    self->tau_rpm = mkvec(
      -arm * t1 - arm * t2 + arm * t3 + arm * t4,
      -arm * t1 + arm * t2 + arm * t3 - arm * t4,
      -t2t * t1 + t2t * t2 - t2t * t3 + t2t * t4
    );
    update_butterworth_2_low_pass_vec(filter_tau_rpm, self->tau_rpm);

    self->tau_rpm_filtered = get_butterworth_2_low_pass_vec(filter_tau_rpm);

    // angular accelleration
    uint64_t timestamp = usecTimestamp();
    float dt = (timestamp - self->timestamp_prev) / 1e6;
    struct vec angular_acc = vdiv(vsub(self->omega, self->omega_prev), dt);
    self->tau_gyro = veltmul(self->J, angular_acc);

    update_butterworth_2_low_pass_vec(filter_angular_acc, angular_acc);

    struct vec angular_acc_filtered = get_butterworth_2_low_pass_vec(filter_angular_acc);
    self->tau_gyro_filtered = veltmul(self->J, angular_acc_filtered);

    self->omega_prev = self->omega;
    self->timestamp_prev = timestamp;

    indi_moments = vsub(self->tau_rpm_filtered, self->tau_gyro_filtered);
    self->u = vadd(self->u, indi_moments);

    // DEBUG
    if (tick % 1000 == 0) {
      DEBUG_PRINT("INDI a %f %f %f, %f %f %f\n", (double)self->tau_rpm_filtered.x, (double)self->tau_rpm_filtered.y, (double)self->tau_rpm_filtered.z, (double)self->tau_gyro_filtered.x, (double)self->tau_gyro_filtered.y, (double)self->tau_gyro_filtered.z);
    }
  }

  control->controlMode = controlModeForceTorque;
  control->torque[0] = self->u.x;
  control->torque[1] = self->u.y;
  control->torque[2] = self->u.z;

  // ticks = usecTimestamp() - startTime;
}

#ifdef CRAZYFLIE_FW

#include "param.h"
#include "log.h"

void controllerOutOfTree4Init(void)
{
  controllerOmarIndiInit(&g_self);
}

bool controllerOutOfTree4Test(void)
{
  return true;
}

void controllerOutOfTree4(control_t *control, const setpoint_t *setpoint,
                                         const sensorData_t *sensors,
                                         const state_t *state,
                                         const uint32_t tick)
{
  controllerOmarIndi(&g_self, control, setpoint, sensors, state, tick);
}

PARAM_GROUP_START(ctrlOmarIndi)
PARAM_ADD(PARAM_FLOAT, KR_x, &g_self.KR.x)
PARAM_ADD(PARAM_FLOAT, KR_y, &g_self.KR.y)
PARAM_ADD(PARAM_FLOAT, KR_z, &g_self.KR.z)
// Attitude I
PARAM_ADD(PARAM_FLOAT, KI_x, &g_self.KI.x)
PARAM_ADD(PARAM_FLOAT, KI_y, &g_self.KI.y)
PARAM_ADD(PARAM_FLOAT, KI_z, &g_self.KI.z)
// Attitude D
PARAM_ADD(PARAM_FLOAT, Kw_x, &g_self.Komega.x)
PARAM_ADD(PARAM_FLOAT, Kw_y, &g_self.Komega.y)
PARAM_ADD(PARAM_FLOAT, Kw_z, &g_self.Komega.z)

// J
PARAM_ADD(PARAM_FLOAT, J_x, &g_self.J.x)
PARAM_ADD(PARAM_FLOAT, J_y, &g_self.J.y)
PARAM_ADD(PARAM_FLOAT, J_z, &g_self.J.z)

// Position P
PARAM_ADD(PARAM_FLOAT, Kpos_Px, &g_self.Kpos_P.x)
PARAM_ADD(PARAM_FLOAT, Kpos_Py, &g_self.Kpos_P.y)
PARAM_ADD(PARAM_FLOAT, Kpos_Pz, &g_self.Kpos_P.z)
PARAM_ADD(PARAM_FLOAT, Kpos_P_limit, &g_self.Kpos_P_limit)
// Position D
PARAM_ADD(PARAM_FLOAT, Kpos_Dx, &g_self.Kpos_D.x)
PARAM_ADD(PARAM_FLOAT, Kpos_Dy, &g_self.Kpos_D.y)
PARAM_ADD(PARAM_FLOAT, Kpos_Dz, &g_self.Kpos_D.z)
PARAM_ADD(PARAM_FLOAT, Kpos_D_limit, &g_self.Kpos_D_limit)
// Position I
PARAM_ADD(PARAM_FLOAT, Kpos_Ix, &g_self.Kpos_I.x)
PARAM_ADD(PARAM_FLOAT, Kpos_Iy, &g_self.Kpos_I.y)
PARAM_ADD(PARAM_FLOAT, Kpos_Iz, &g_self.Kpos_I.z)
PARAM_ADD(PARAM_FLOAT, Kpos_I_limit, &g_self.Kpos_I_limit)

PARAM_ADD(PARAM_FLOAT, mass, &g_self.mass)

PARAM_ADD(PARAM_UINT8, indi, &g_self.indi)

PARAM_GROUP_STOP(ctrlOmarIndi)


LOG_GROUP_START(ctrlOmarIndi)

LOG_ADD(LOG_FLOAT, KR_x, &g_self.KR.x)
LOG_ADD(LOG_FLOAT, KR_y, &g_self.KR.y)
LOG_ADD(LOG_FLOAT, KR_z, &g_self.KR.z)
LOG_ADD(LOG_FLOAT, Kw_x, &g_self.Komega.x)
LOG_ADD(LOG_FLOAT, Kw_y, &g_self.Komega.y)
LOG_ADD(LOG_FLOAT, Kw_z, &g_self.Komega.z)

LOG_ADD(LOG_FLOAT,Kpos_Px, &g_self.Kpos_P.x)
LOG_ADD(LOG_FLOAT,Kpos_Py, &g_self.Kpos_P.y)
LOG_ADD(LOG_FLOAT,Kpos_Pz, &g_self.Kpos_P.z)
LOG_ADD(LOG_FLOAT,Kpos_Dx, &g_self.Kpos_D.x)
LOG_ADD(LOG_FLOAT,Kpos_Dy, &g_self.Kpos_D.y)
LOG_ADD(LOG_FLOAT,Kpos_Dz, &g_self.Kpos_D.z)


LOG_ADD(LOG_FLOAT, thrustSi, &g_self.thrustSi)
LOG_ADD(LOG_FLOAT, torquex, &g_self.u.x)
LOG_ADD(LOG_FLOAT, torquey, &g_self.u.y)
LOG_ADD(LOG_FLOAT, torquez, &g_self.u.z)

// current angles
LOG_ADD(LOG_FLOAT, rpyx, &g_self.rpy.x)
LOG_ADD(LOG_FLOAT, rpyy, &g_self.rpy.y)
LOG_ADD(LOG_FLOAT, rpyz, &g_self.rpy.z)

// desired angles
LOG_ADD(LOG_FLOAT, rpydx, &g_self.rpy_des.x)
LOG_ADD(LOG_FLOAT, rpydy, &g_self.rpy_des.y)
LOG_ADD(LOG_FLOAT, rpydz, &g_self.rpy_des.z)

// errors
LOG_ADD(LOG_FLOAT, error_posx, &g_self.p_error.x)
LOG_ADD(LOG_FLOAT, error_posy, &g_self.p_error.y)
LOG_ADD(LOG_FLOAT, error_posz, &g_self.p_error.z)

LOG_ADD(LOG_FLOAT, error_velx, &g_self.v_error.x)
LOG_ADD(LOG_FLOAT, error_vely, &g_self.v_error.y)
LOG_ADD(LOG_FLOAT, error_velz, &g_self.v_error.z)

// omega
LOG_ADD(LOG_FLOAT, omegax, &g_self.omega.x)
LOG_ADD(LOG_FLOAT, omegay, &g_self.omega.y)
LOG_ADD(LOG_FLOAT, omegaz, &g_self.omega.z)

// omega_r
LOG_ADD(LOG_FLOAT, omegarx, &g_self.omega_r.x)
LOG_ADD(LOG_FLOAT, omegary, &g_self.omega_r.y)
LOG_ADD(LOG_FLOAT, omegarz, &g_self.omega_r.z)

// omega_des_dot
LOG_ADD(LOG_FLOAT, omegaddx, &g_self.omega_des_dot.x)
LOG_ADD(LOG_FLOAT, omegaddy, &g_self.omega_des_dot.y)
LOG_ADD(LOG_FLOAT, omegaddz, &g_self.omega_des_dot.z)

// LOG_ADD(LOG_UINT32, ticks, &ticks)

// INDI
LOG_ADD(LOG_FLOAT, f_rpm, &g_self.f_rpm)         // compare to thrustSi
LOG_ADD(LOG_FLOAT, tau_rpmx, &g_self.tau_rpm.x)  // compare to torquex
LOG_ADD(LOG_FLOAT, tau_rpmy, &g_self.tau_rpm.y)  // compare to torquey
LOG_ADD(LOG_FLOAT, tau_rpmz, &g_self.tau_rpm.z)  // compare to torquez

LOG_ADD(LOG_FLOAT, tau_rpm_fx, &g_self.tau_rpm_filtered.x)  // compare to torquex
LOG_ADD(LOG_FLOAT, tau_rpm_fy, &g_self.tau_rpm_filtered.y)  // compare to torquey
LOG_ADD(LOG_FLOAT, tau_rpm_fz, &g_self.tau_rpm_filtered.z)  // compare to torquez

LOG_ADD(LOG_FLOAT, tau_gyro_x, &g_self.tau_gyro.x)  // compare to torquex
LOG_ADD(LOG_FLOAT, tau_gyro_y, &g_self.tau_gyro.y)  // compare to torquey
LOG_ADD(LOG_FLOAT, tau_gyro_z, &g_self.tau_gyro.z)  // compare to torquez

LOG_ADD(LOG_FLOAT, tau_gyro_fx, &g_self.tau_gyro_filtered.x)  // compare to torquex
LOG_ADD(LOG_FLOAT, tau_gyro_fy, &g_self.tau_gyro_filtered.y)  // compare to torquey
LOG_ADD(LOG_FLOAT, tau_gyro_fz, &g_self.tau_gyro_filtered.z)  // compare to torquez

LOG_ADD(LOG_FLOAT, a_rpmx, &g_self.a_rpm.x)
LOG_ADD(LOG_FLOAT, a_rpmy, &g_self.a_rpm.y)
LOG_ADD(LOG_FLOAT, a_rpmz, &g_self.a_rpm.z)

LOG_ADD(LOG_FLOAT, a_rpm_fx, &g_self.a_rpm_filtered.x)
LOG_ADD(LOG_FLOAT, a_rpm_fy, &g_self.a_rpm_filtered.y)
LOG_ADD(LOG_FLOAT, a_rpm_fz, &g_self.a_rpm_filtered.z)

LOG_ADD(LOG_FLOAT, a_imux, &g_self.a_imu.x)
LOG_ADD(LOG_FLOAT, a_imuy, &g_self.a_imu.y)
LOG_ADD(LOG_FLOAT, a_imuz, &g_self.a_imu.z)

LOG_ADD(LOG_FLOAT, a_imu_fx, &g_self.a_imu_filtered.x)
LOG_ADD(LOG_FLOAT, a_imu_fy, &g_self.a_imu_filtered.y)
LOG_ADD(LOG_FLOAT, a_imu_fz, &g_self.a_imu_filtered.z)



LOG_GROUP_STOP(ctrlOmarIndi)

PARAM_GROUP_START(ctrlFbl)
PARAM_ADD(PARAM_UINT8, en, &g_self.fbl.en)
PARAM_ADD_WITH_CALLBACK(PARAM_UINT8, preset, &g_self.fbl.preset, fbl_preset_changed)
PARAM_ADD(PARAM_FLOAT, cd, &g_self.fbl.c_d)
PARAM_ADD(PARAM_FLOAT, z_on, &g_self.fbl.z_on)
PARAM_ADD(PARAM_FLOAT, z_off, &g_self.fbl.z_off)
PARAM_ADD(PARAM_FLOAT, tilt_max, &g_self.fbl.tilt_max_deg)
PARAM_ADD(PARAM_FLOAT, kp_xy, &g_self.fbl.kp_xy)
PARAM_ADD(PARAM_FLOAT, kp_z, &g_self.fbl.kp_z)
PARAM_ADD(PARAM_FLOAT, kv_xy, &g_self.fbl.kv_xy)
PARAM_ADD(PARAM_FLOAT, kv_z, &g_self.fbl.kv_z)
PARAM_ADD(PARAM_FLOAT, ki_xy, &g_self.fbl.ki_xy)
PARAM_ADD(PARAM_FLOAT, ki_z, &g_self.fbl.ki_z)
PARAM_ADD(PARAM_FLOAT, kr_xy, &g_self.fbl.kr_xy)
PARAM_ADD(PARAM_FLOAT, kr_z, &g_self.fbl.kr_z)
PARAM_ADD(PARAM_FLOAT, J_x, &g_self.fbl.J.x)
PARAM_ADD(PARAM_FLOAT, J_y, &g_self.fbl.J.y)
PARAM_ADD(PARAM_FLOAT, J_z, &g_self.fbl.J.z)
PARAM_ADD(PARAM_FLOAT, beta, &g_self.fbl.beta)
PARAM_ADD(PARAM_FLOAT, gamma, &g_self.fbl.gamma)
PARAM_ADD(PARAM_FLOAT, w_max, &g_self.fbl.w_max)
PARAM_ADD(PARAM_UINT8, inner, &g_self.fbl.inner)
PARAM_ADD(PARAM_UINT8, abg_on_new, &g_self.fbl.abg_on_new)
PARAM_ADD(PARAM_UINT8, nn_en, &g_self.fbl.nn_en)
PARAM_GROUP_STOP(ctrlFbl)

LOG_GROUP_START(ctrlFbl)
LOG_ADD(LOG_UINT8, active, &g_self.fbl.active)
LOG_ADD(LOG_UINT8, tripped, &g_self.fbl.tripped)
LOG_ADD(LOG_UINT32, steps, &g_self.fbl.steps)
LOG_ADD(LOG_UINT32, faults, &g_self.fbl.faults)
LOG_ADD(LOG_FLOAT, res_az, &g_self.fbl.res_az)
LOG_ADD(LOG_FLOAT, res_jz, &g_self.fbl.res_jz)
LOG_ADD(LOG_FLOAT, thrust, &g_self.fbl.thrust)
LOG_ADD(LOG_FLOAT, acc_z, &g_self.fbl.acc_cmd.z)
LOG_ADD(LOG_FLOAT, w_des_x, &g_self.fbl.w_des.x)
LOG_ADD(LOG_FLOAT, w_des_y, &g_self.fbl.w_des.y)
LOG_ADD(LOG_FLOAT, w_des_z, &g_self.fbl.w_des.z)
LOG_ADD(LOG_FLOAT, yaw_sp, &g_self.fbl.yaw_sp)
LOG_GROUP_STOP(ctrlFbl)

#endif // CRAZYFLIE_FW defined
