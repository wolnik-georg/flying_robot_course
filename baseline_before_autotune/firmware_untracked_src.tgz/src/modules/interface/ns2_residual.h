/*
 * NS2 (Neural-Swarm 2) learned interaction residual, C implementation for the Omar C controller tree.
 *
 * Reproduces flying_drone_stack/firmware_app/src/residual_nn.rs (ResidualNet::eval) and the peer handling in
 * src/lib.rs (rnn_predict_eval / rnn_predict). Specification: docs/ns2_c_module_spec.md in flying_robot_course.
 *
 * Output is a world-frame acceleration, z component only, in m/s^2: the network's estimate of the measured
 * residual (a_meas - a_model). The Omar controller subtracts it (a_d - a_nn), the same sign as its own INDI term.
 *
 * Weights are flash-resident, generated from the frozen .npz by tools/residual/export_weights_c.py into
 * firmware_app/ns2_weights.c (symbols ns2_w_phi_s / ns2_w_phi_g / ns2_w_rho_s). Parameters and logs are the
 * existing rnn.* group of traj_iface.c; this module only reads/writes those globals.
 */
#ifndef __NS2_RESIDUAL_H__
#define __NS2_RESIDUAL_H__

#include <stdint.h>
#include <stdbool.h>

#define NS2_MAX_NEIGHBOURS 3

typedef struct {
  float x, y, z;
  uint32_t ts;
} ns2_peer_prev_t;

typedef struct {
  ns2_peer_prev_t prev[NS2_MAX_NEIGHBOURS];  // previous peer sample (position, timestamp ms)
  float vel[NS2_MAX_NEIGHBOURS][3];          // last peer velocity estimate
  float hold[3];                             // last evaluated prediction (world frame, m/s^2)
  uint8_t hold_clamped;                      // clamp / fault flag of the held evaluation
  uint8_t started;                           // 0 until the first evaluation
} ns2_state_t;

void ns2_reset(ns2_state_t *s);

/* True when the flash weights are linked into this image. */
bool ns2_weights_present(void);

/* Full evaluation from peer_get_all(); updates the peer-velocity history in s.
 * pos/vel: own position (m) and velocity (m/s), world frame. mass: kg. */
void ns2_eval(ns2_state_t *s, const float pos[3], const float vel[3], float mass,
              float out_accel[3], uint8_t *clamped);

/* Same, with relative states given explicitly (no peer history). rel_p[k] = peer position - own position,
 * rel_v[k] = peer velocity - own velocity, k < n <= NS2_MAX_NEIGHBOURS. own_z / own_vel feed the ground term. */
void ns2_eval_rel(const float rel_p[][3], const float rel_v[][3], int n,
                  float own_z, const float own_vel[3], float mass,
                  float out_accel[3], uint8_t *clamped);

/* Controller glue, called once per executed controller tick with the main-loop tick:
 *  - sets rnn.ready (weights are in flash), honours rnn.div / rnn.rst,
 *  - evaluates on the first call and whenever tick % rnn.div == 0, otherwise republishes the held value,
 *  - writes rnn.pred_x/y/z, rnn.clamped, rnn.us_*.
 * The result is in s->hold. Always evaluates (and logs), whatever rnn.en says. */
void ns2_update(ns2_state_t *s, const float pos[3], const float vel[3], float mass, uint32_t tick);

/* Firmware only: publish rnn.ready = 1 (the weights are in flash). Called at controller init and from ns2_update so the
 * flag reads 1 as soon as controller 9 is selected, before any setpoint. No-op in host/SIL builds, where rnn.* globals
 * are shared between drones and controllers and must not be touched as a side effect. */
void ns2_publish_ready(void);

/* rnn.en != 0 and the weights are present (firmware: and rnn.ready): the prediction may be used by the controller. */
bool ns2_active(void);

#endif // __NS2_RESIDUAL_H__
