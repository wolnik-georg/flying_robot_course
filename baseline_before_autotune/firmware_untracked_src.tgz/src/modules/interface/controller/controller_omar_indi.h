/*
The MIT License (MIT)

Copyright (c) 2024 Khaled Wahba

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#ifndef __CONTROLLER_OMAR_INDI_H__
#define __CONTROLLER_OMAR_INDI_H__

#include "stabilizer_types.h"
#include "ns2_residual.h"
#include "fbl_residual.h"
#include "fbl_law.h"

// Learned feedback linearization (Strategy 3, 2026-10-19): configuration and state, additive; inert unless en = 1
typedef struct {
    uint8_t en;          // 0 = Omar controller as before (bit-identical), 1 = FBL above z_on
    float c_d;           // ROM drag coefficient
    float z_on, z_off;   // handover heights [m] (hysteresis): below, the Omar controller runs
    float tilt_max_deg;  // fall back to the Omar controller above this tilt (latched until landed)
    uint8_t preset;      // gain preset: 0 = authors' values, 1 = ours (see fbl_apply_preset in the .c)
    float kp_xy, kp_z, kv_xy, kv_z, ki_xy, ki_z, kr_xy, kr_z;  // position / velocity / integral / body-rate gains
    struct vec J;        // inertia used by the FBL torque [kg m^2]
    float beta, gamma;   // acceleration estimator gains
    float w_max;         // limit of the commanded body rates [rad/s]
    uint8_t inner;       // inner loop: 1 = stock rate PID (paper hardware, default since 2026-10-25); 0 = Eq. 19 P-only body-rate loop, force-torque (as flown 2026-10-24)
    uint8_t abg_on_new;  // alpha-beta-gamma estimator: 0 = updated every controller tick (as flown); 1 = only on a new EKF velocity (measurement rate)
    uint8_t nn_en;       // force network on top of the ROM (paper hardware recipe): 1 = ROM + fbl_nn_weights (default since 2026-10-25, no effect if no weights are linked); 0 = ROM only (as flown 2026-10-24)
    // state / logging
    uint8_t active, tripped;
    float yaw_sp;        // inner = 1: yaw setpoint integrated from the commanded body z rate [deg], as controller_pid.c in rate mode
    float abg_v[3], abg_age;  // abg_on_new = 1: last velocity sample and time since it changed [s]
    uint32_t steps, faults;
    fbl_law_state_t law;
    fbl_state_t peers;
    float res_az, res_jz, thrust;
    struct vec acc_cmd, w_des;
} fbl_cfg_t;

// This structure contains the mutable state and inmutable parameters
typedef struct controllerOmarIndi_s {
    float mass;
    float thrustSi;
    struct vec J; // Inertia matrix (diagonal matrix); kg m^2

    // Position PID
    struct vec Kpos_P; // Kp in paper
    float Kpos_P_limit;
    struct vec Kpos_D; // Kv in paper
    float Kpos_D_limit;
    struct vec Kpos_I; // not in paper
    float Kpos_I_limit;
    struct vec i_error_pos;
    struct vec p_error;
    struct vec v_error;
    // Attitude PID
    struct vec KR;
    struct vec Komega;
    struct vec KI;
    struct vec i_error_att;
    // INDI
    uint8_t indi;
    struct vec omega_prev;
    uint64_t timestamp_prev;
    // INDI - logging
    float f_rpm;
    struct vec tau_rpm;
    struct vec tau_rpm_filtered;
    struct vec tau_gyro_filtered;
    struct vec tau_gyro;

    struct vec a_rpm;
    struct vec a_rpm_filtered;
    struct vec a_imu;
    struct vec a_imu_filtered;

    // Logging variables
    struct vec rpy;
    struct vec rpy_des;
    struct mat33 R_des;
    struct vec omega;
    struct vec omega_r;
    struct vec u;
    struct vec omega_des_dot;

    // NS2 learned residual (2026-10-14, additive; inert unless rnn.en = 1)
    ns2_state_t ns2;
    // Learned FBL (2026-10-19, additive; inert unless fbl.en = 1)
    fbl_cfg_t fbl;
} controllerOmarIndi_t;


void controllerOmarIndiInit(controllerOmarIndi_t* self);
void controllerOmarIndiReset(controllerOmarIndi_t* self);
void controllerOmarIndi(controllerOmarIndi_t* self, control_t *control, const setpoint_t *setpoint,
                                         const sensorData_t *sensors,
                                         const state_t *state,
                                         const uint32_t tick);

#ifdef CRAZYFLIE_FW
void controllerOutOfTree4Init(void);
bool controllerOutOfTree4Test(void);
void controllerOutOfTree4(control_t *control, const setpoint_t *setpoint,
                                         const sensorData_t *sensors,
                                         const state_t *state,
                                         const uint32_t tick);
#endif // CRAZYFLIE_FW defined

#endif //__CONTROLLER_OMAR_INDI_H__
